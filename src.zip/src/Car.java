//					IS A
public class Car extends Vehicle {

	//car has other imp - ac, music
	
	
	public void playMusic() {
		System.out.println("<<<<< la la la .... >>>>>");
	}
	
}
