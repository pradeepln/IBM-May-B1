
public class Driver {
	
	public void drive(Vehicle v) {
		v.start();
		System.out.println("<<<<< Taking it out for a spin >>>>>");
		v.stop();
	}
	


}
