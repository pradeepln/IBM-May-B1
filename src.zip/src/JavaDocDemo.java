/**
 * 
 * @author pradeep
 *This is the class level documentation of call called JavaDocDemo
 */
public class JavaDocDemo {
	
	/**
	 * this age var decides how long this object to be held
	 */
	int age = 10;
	
	/**
	 * This is a useless javadoc to say this is the default constructor
	 */
	public JavaDocDemo() {
		
	}
	
	
	/**
	 * Just a method to cheer you up!
	 * @return a message to cheer you?
	 */
	public String sayHello() {
		return "Hello!";
	}

}
