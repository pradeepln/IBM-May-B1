
public class PrimitiveRangeOfValues {

	public static void main(String[] args) {
		//boolean b = 0;
		int i = 20;
		
		System.out.println("i = "+i);
		
		System.out.println("Max of int = "+Integer.MAX_VALUE);
		
		System.out.println("Min of int = "+Integer.MIN_VALUE);

		i++;
		System.out.println("i = "+i);
		
		i = Integer.MAX_VALUE;
		i++;
		System.out.println("i = "+i);
		
	}

}
