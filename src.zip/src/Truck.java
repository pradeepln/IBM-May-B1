//					IS A
public class Truck extends Vehicle{

	//stuff like -- loading goods etc
}
