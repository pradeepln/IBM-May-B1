
public class Vehicle {
	//lots of useful impl details - engine , tank battery 
	
	public void start() {
		System.out.println("------- Vehicle Strart -------");
	}
	
	public void stop() {
		System.out.println("------- Vehicle Stop -------");
	}
}
